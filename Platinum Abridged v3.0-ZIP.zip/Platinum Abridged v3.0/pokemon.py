import random

from PokemonCollectionv3 import speciesList
from StatCalcv2 import ivCalculator
from StatCalcv2 import statCalc
from StatCalcv2 import xpCalc
from utilities import load_front_sprite


pList = speciesList



class Pokemon:
    def __init__(self, pNum, species, gender, nature, ivSpread, level, xp, stats, type1, type2, hp, isShiny):
        self.pNum = pNum
        self.species = species
        self.gender = gender
        self.nature = nature
        self.ivSpread = ivSpread
        self.level = level
        self.xp = xp
        self.stats = stats
        self.type1 = type1
        self.type2 = type2
        self.hp = hp
        self.isShiny = isShiny
    
    def evolve(self):
        self.species = pList[self.pNum][4][1]
        i = 0
        found = False
        while i < len(pList) and found == False:
            if pList[i][1].lower() == self.species.lower():
                self.pNum = i
                found = True
            i += 1

        ev = [0, 0, 0, 0, 0, 0]

        self.stats = statCalc(self.pNum, self.nature, self.ivSpread, self.level, ev)

        self.type1 = speciesList[self.pNum][3][0]
        self.type2 = speciesList[self.pNum][3][1]

        self.hp = self.stats[0]
        
    

def shinyChance():
    shiny = False
    if random.randint(1, 8192) == 1:
        shiny = True
    return shiny




def create_pokemon(pNum = 0, species = 'MissingNo', gender = 'undefined', nature = 'undefined', ivSpread = [], level = 0, xp = 0, stats = [], hp = 0, isShiny = False):
    if pNum == 0 and species == 'MissingNo':
        pNum = pList[random.randint(1, 98)][0]
        species = pList[pNum][1]

    elif pNum != 0 and species == 'MissingNo':
        species = pList[pNum][1]
    
    elif pNum == 0 and species != 'MissingNo':
        i = 0
        found = False
        while i < len(pList) and found == False:
            if pList[i][1].lower() == species.lower():
                pNum = i
                found = True
            i += 1
    
    else:
        if species != pList[pNum][1]:
            pNum = 0
            species = 'MissingNo'



    if gender == 'undefined':
        genders = ['Boy', 'Girl']
        gender = random.choice(genders)

        with open('GenderlessList.txt') as g:
            lines2 = g.readlines()
            i = 0
            while i < len(lines2):
                if species == lines2[i].rstrip():
                    gender = 'Genderless'
                i += 1
        with open('BoyList.txt') as b:
            lines3 = b.readlines()
            i = 0
            while i < len(lines3):
                if species == lines3[i].rstrip():
                    gender = 'Boy'
                i += 1
        with open('GirlList.txt') as g:
            lines4 = g.readlines()
            i = 0
            while i < len(lines4):
                if species == lines4[i].rstrip():
                    gender = 'Girl'
                i += 1

    with open('NatureList.txt') as n:
        lines5 = n.readlines()
        nature = lines5[random.randint(0,24)].rstrip()

    if ivSpread == []:
        ivSpread = ivCalculator()

    if level == 0:
        level = random.randint(1, 100)
    
    if xp == 0:
        xp = xpCalc(level)

    ev = [0, 0, 0, 0, 0, 0]

    stats = statCalc(pNum, nature, ivSpread, level, ev)

    type1 = speciesList[pNum][3][0]
    type2 = speciesList[pNum][3][1]

    hp = stats[0]

    isShiny = shinyChance()

    return Pokemon(pNum, species, gender, nature, ivSpread, level, xp, stats, type1, type2, hp, isShiny)

