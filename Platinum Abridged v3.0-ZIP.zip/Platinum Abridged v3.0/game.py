#Pokemon Game


import pygame
import sys
import random


from pokemon import create_pokemon
from move import create_move
from trainer import Trainer
from randomPokemon import random_wild_pokemon, random_trainer
from StatCalcv2 import damage_calculator, calculate_effectiveness, xpGain
from assets import front_sprite_list, trainer_image_list, move_list
from button import Button
from graphics import draw_text_box, draw_evolution, draw_player_pokemon_box, draw_opposing_pokemon_box
from PokemonCollectionv3 import speciesList



pList = speciesList

class Game:
    def __init__(self):
        pygame.init()

        pygame.display.set_caption('Platinum Abridged')

        scr_res = (1250, 900)

        self.screen = pygame.display.set_mode(scr_res)

        self.display = pygame.Surface((1250, 900))

        self.txt_box = pygame.Rect(50, 660, 1150, 180)
        
        self.font = pygame.font.Font('freesansbold.ttf', 32)
        self.txt_box_font = pygame.font.Font('freesansbold.ttf', 48)
        
        self.clock = pygame.time.Clock()

        self.player = Trainer("Player", [], 0, 0)
        self.opposing_trainer = Trainer("Opposition", [], 0, 0)

        #Used to determine if the opponent has an active pokemon on the field
        self.opposing_active_pokemon = False
        self.opposing_remaining_pokemon = 0
        

        self.player_pokemon = create_pokemon(pNum = 0)
        self.opposing_pokemon = create_pokemon(pNum = 0)

        self.front_sprites = front_sprite_list
        self.trainer_images = trainer_image_list
        self.moves = move_list

        #So the home music doesn't repeat itself every frame
        self.home_music = False

        #Used to check if a wild pokemon was already created
        self.pokemon_created = False

        #These are used when the text box at the end of the loop should be ignored
        #Used when displaying what each pokemon used
        self.battle_text = False
        self.is_evolving = False

        #Used when choosing a new pokemon for battle
        self.in_battle = False

        self.pokemon_buttons = []
        self.battle_buttons = []

        self.battle_buttons_created = False

        self.intro_count = 0


        #Set to test when trying new things
        self.game_state = 'intro'

        #Used to hold wild battle, trainer battle, or gym battle
        self.temp_state = ''

        #Used when the player selects a move, used in damage calculations
        self.battle_phase = 0

        

    def create_pokemon_buttons(self):
        self.pokemon_buttons = []
        if len(self.player.party) >= 1:
            self.pokemon_buttons.append(Button(self.screen, 180, 100, self.player.party[0].species))
        if len(self.player.party) >= 2:
            self.pokemon_buttons.append(Button(self.screen, 820, 100, self.player.party[1].species))
        if len(self.player.party) >= 3:
            self.pokemon_buttons.append(Button(self.screen, 180, 250, self.player.party[2].species))
        if len(self.player.party) >= 4:
            self.pokemon_buttons.append(Button(self.screen, 820, 250, self.player.party[3].species))
        if len(self.player.party) >= 5:
            self.pokemon_buttons.append(Button(self.screen, 180, 400, self.player.party[4].species))
        if len(self.player.party) >= 6:
            self.pokemon_buttons.append(Button(self.screen, 820, 400, self.player.party[5].species))
        #This is only used when catching a 7th pokemon
        if len(self.player.party) >= 7:
            self.pokemon_buttons.append(Button(self.screen, 480, 550, self.player.party[6].species))

        #Have to set this to false whenever the player modifies their party
        self.pokemon_buttons_created = True

    def create_battle_buttons(self):
        self.battle_buttons = []

        #Primary type
        match self.player_pokemon.type1:

            case 'NORMAL':
                self.battle_buttons.append(Button(self.screen, 40, 90, "NORMAL PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "NORMAL SP"))
            case 'GRASS':
                self.battle_buttons.append(Button(self.screen, 40, 90, "GRASS PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "GRASS SP"))
            case 'FIRE':
                self.battle_buttons.append(Button(self.screen, 40, 90, "FIRE PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "FIRE SP"))
            case 'WATER':
                self.battle_buttons.append(Button(self.screen, 40, 90, "WATER PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "WATER SP"))
            case 'ELECTRIC':
                self.battle_buttons.append(Button(self.screen, 40, 90, "ELECTRIC PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "ELECTRIC SP"))
            case 'FLYING':
                self.battle_buttons.append(Button(self.screen, 40, 90, "FLYING PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "FLYING SP"))
            case 'BUG':
                self.battle_buttons.append(Button(self.screen, 40, 90, "BUG PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "BUG SP"))
            case 'FIGHTING':
                self.battle_buttons.append(Button(self.screen, 40, 90, "FIGHTING PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "FIGHTING SP"))
            case 'PSYCHIC':
                self.battle_buttons.append(Button(self.screen, 40, 90, "PSYCHIC PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "PSYCHIC SP"))
            case 'DARK':
                self.battle_buttons.append(Button(self.screen, 40, 90, "DARK PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "DARK SP"))
            case 'GHOST':
                self.battle_buttons.append(Button(self.screen, 40, 90, "GHOST PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "GHOST SP"))
            case'POISON':
                self.battle_buttons.append(Button(self.screen, 40, 90, "POISON PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "POISON SP"))
            case'GROUND':
                self.battle_buttons.append(Button(self.screen, 40, 90, "GROUND PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "GROUND SP"))
            case'ROCK':
                self.battle_buttons.append(Button(self.screen, 40, 90, "ROCK PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "ROCK SP"))
            case 'STEEL':
                self.battle_buttons.append(Button(self.screen, 40, 90, "STEEL PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "STEEL SP"))
            case 'ICE':
                self.battle_buttons.append(Button(self.screen, 40, 90, "ICE PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "ICE SP"))
            case 'DRAGON':
                self.battle_buttons.append(Button(self.screen, 40, 90, "DRAGON PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "DRAGON SP"))
            case 'FAIRY':
                self.battle_buttons.append(Button(self.screen, 40, 90, "FAIRY PHYS"))
                self.battle_buttons.append(Button(self.screen, 40, 160, "FAIRY SP"))
            case _:
                pass

        #Secondary type
        match self.player_pokemon.type2:

            case 'NORMAL':
                self.battle_buttons.append(Button(self.screen, 260, 90, "NORMAL PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "NORMAL SP"))
            case 'GRASS':
                self.battle_buttons.append(Button(self.screen, 260, 90, "GRASS PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "GRASS SP"))
            case 'FIRE':
                self.battle_buttons.append(Button(self.screen, 260, 90, "FIRE PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "FIRE SP"))
            case 'WATER':
                self.battle_buttons.append(Button(self.screen, 260, 90, "WATER PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "WATER SP"))
            case 'ELECTRIC':
                self.battle_buttons.append(Button(self.screen, 260, 90, "ELECTRIC PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "ELECTRIC SP"))
            case 'FLYING':
                self.battle_buttons.append(Button(self.screen, 260, 90, "FLYING PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "FLYING SP"))
            case 'BUG':
                self.battle_buttons.append(Button(self.screen, 260, 90, "BUG PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "BUG SP"))
            case 'FIGHTING':
                self.battle_buttons.append(Button(self.screen, 260, 90, "FIGHTING PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "FIGHTING SP"))
            case 'PSYCHIC':
                self.battle_buttons.append(Button(self.screen, 260, 90, "PSYCHIC PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "PSYCHIC SP"))
            case 'DARK':
                self.battle_buttons.append(Button(self.screen, 260, 90, "DARK PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "DARK SP"))
            case 'GHOST':
                self.battle_buttons.append(Button(self.screen, 260, 90, "GHOST PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "GHOST SP"))
            case 'POISON':
                self.battle_buttons.append(Button(self.screen, 260, 90, "POISON PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "POISON SP"))
            case 'GROUND':
                self.battle_buttons.append(Button(self.screen, 260, 90, "GROUND PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "GROUND SP"))
            case 'ROCK':
                self.battle_buttons.append(Button(self.screen, 260, 90, "ROCK PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "ROCK SP"))
            case 'STEEL':
                self.battle_buttons.append(Button(self.screen, 260, 90, "STEEL PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "STEEL SP"))
            case 'ICE':
                self.battle_buttons.append(Button(self.screen, 260, 90, "ICE PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "ICE SP"))
            case 'DRAGON':
                self.battle_buttons.append(Button(self.screen, 260, 90, "DRAGON PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "DRAGON SP"))
            case 'FAIRY':
                self.battle_buttons.append(Button(self.screen, 260, 90, "FAIRY PHYS"))
                self.battle_buttons.append(Button(self.screen, 260, 160, "FAIRY SP"))
            case _:
                pass

        #Set to false after leaving battle screen
        self.battle_buttons_created = True


    
    black = (0, 0, 0)
    white = (255, 255, 255)
    

    def draw_text(self, text, font, color, x, y):
        img = font.render(text, True, color)
        self.screen.blit(img, (x, y))

        

    def run(self):

        #Starter selection buttons
        starter1 = Button(self.screen, 180, 400, "Turtwig")
        starter2 = Button(self.screen, 500, 400, "Chimchar")
        starter3 = Button(self.screen, 820, 400, "Piplup")

        #Home menu buttons
        wild_encounter = Button(self.screen, 180, 200, "Wild Encounter")
        trainer_battle = Button(self.screen, 500, 200, "Battle Trainer")
        take_on_gym = Button(self.screen, 820, 200, "Take on Gym")
        check_pokemon = Button(self.screen, 180, 380, "Check Pokemon")
        pokemon_center = Button(self.screen, 500, 380, "Pokemon Center")
        shop_button = Button(self.screen, 820, 380, "Shop")


        #Wilde encounter buttons
        battle_wild = Button(self.screen, 50, 200, "Battle")
        catch_wild = Button(self.screen, 50, 300, "Catch")
        run_away = Button(self.screen, 50, 400, "Run Away")





        #Return Home Button
        #Used whenever necessary during testing
        return_home = Button(self.screen, 5, 5, "Return Home")
        #Used in actuaal gameplay when necessary
        return_button = Button(self.screen, 5, 5, "Return")

        pygame.mixer.music.load('data/music/introtheme.mp3')
        pygame.mixer.music.play(-1)
        
            
        while True:
            #Sets color of display
            self.display.fill((196, 228, 255))

            #blits display onto the screen
            self.screen.blit(self.display, (0, 0))

            txt_box_txt = ''

            healthy_pokemon = 0
            for i, pokemon in enumerate(self.player.party):
                if pokemon.hp > 0:
                    healthy_pokemon += 1



            match self.game_state:

                case 'test':
                    pygame.mixer.music.stop()
                    self.is_evolving = True
                    draw_evolution(self.screen, create_pokemon(species = 'Chimchar'))
                    pass


                case 'intro':

                    #Sets color of display to a yellow akin to Pokemon Platinum's intro
                    self.display.fill((245, 242, 181))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    pygame.draw.rect(self.screen, (239, 233, 164), pygame.Rect(0, 75, 1250, 30))
                    pygame.draw.rect(self.screen, (233, 224, 146), pygame.Rect(0, 60, 1250, 30))
                    pygame.draw.rect(self.screen, (226, 214, 128), pygame.Rect(0, 45, 1250, 30))
                    pygame.draw.rect(self.screen, (220, 205, 110), pygame.Rect(0, 30, 1250, 30))
                    pygame.draw.rect(self.screen, (214, 196, 93), pygame.Rect(0, 15, 1250, 30))
                    pygame.draw.rect(self.screen, (208, 187, 76), pygame.Rect(0, 0, 1250, 30))

                    pygame.draw.rect(self.screen, (239, 233, 164), pygame.Rect(0, 535, 1250, 200))
                    pygame.draw.rect(self.screen, (233, 224, 146), pygame.Rect(0, 550, 1250, 200))
                    pygame.draw.rect(self.screen, (226, 214, 128), pygame.Rect(0, 565, 1250, 200))
                    pygame.draw.rect(self.screen, (220, 205, 110), pygame.Rect(0, 580, 1250, 200))
                    pygame.draw.rect(self.screen, (214, 196, 93), pygame.Rect(0, 595, 1250, 200))
                    pygame.draw.rect(self.screen, (208, 187, 76), pygame.Rect(0, 610, 1250, 1400))

                    rowan_img = pygame.transform.scale(self.trainer_images['prof rowan'], (300, 583))
                    self.screen.blit(rowan_img, (433, 55))


                    match self.intro_count:
                        case 0:
                            txt_box_txt = "Hello! Welcome to the world of pokemon! I am Professor Rowan."
                        case 1:
                            txt_box_txt = "There are many pokemon in this world for you to catch and befriend."
                        case 2:
                            txt_box_txt = "Battle your way through the pokemon gyms and take on the champion!"
                        case 3:
                            txt_box_txt = "Oh! You probably need a pokemon in order to battle."
                        case 4:
                            txt_box_txt = "Here, you can take one of mine!"
                        case 5:
                            self.game_state = 'starter choice'
                        case _:
                            txt_box_txt = "Something is wrong, please exit the window"

                    for event in pygame.event.get():

                        if event.type == pygame.MOUSEBUTTONUP:
                            self.intro_count += 1

                        if event.type == pygame.QUIT:
                            pygame.quit()
                            sys.exit()
                            
                #Beginning of game
                case 'starter choice':

                    #Sets color of display to a yellow akin to Pokemon Platinum's intro
                    self.display.fill((245, 242, 181))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    pygame.draw.rect(self.screen, (239, 233, 164), pygame.Rect(0, 75, 1250, 30))
                    pygame.draw.rect(self.screen, (233, 224, 146), pygame.Rect(0, 60, 1250, 30))
                    pygame.draw.rect(self.screen, (226, 214, 128), pygame.Rect(0, 45, 1250, 30))
                    pygame.draw.rect(self.screen, (220, 205, 110), pygame.Rect(0, 30, 1250, 30))
                    pygame.draw.rect(self.screen, (214, 196, 93), pygame.Rect(0, 15, 1250, 30))
                    pygame.draw.rect(self.screen, (208, 187, 76), pygame.Rect(0, 0, 1250, 30))

                    pygame.draw.rect(self.screen, (239, 233, 164), pygame.Rect(0, 535, 1250, 200))
                    pygame.draw.rect(self.screen, (233, 224, 146), pygame.Rect(0, 550, 1250, 200))
                    pygame.draw.rect(self.screen, (226, 214, 128), pygame.Rect(0, 565, 1250, 200))
                    pygame.draw.rect(self.screen, (220, 205, 110), pygame.Rect(0, 580, 1250, 200))
                    pygame.draw.rect(self.screen, (214, 196, 93), pygame.Rect(0, 595, 1250, 200))
                    pygame.draw.rect(self.screen, (208, 187, 76), pygame.Rect(0, 610, 1250, 1400))


                    #puts text onto textbox
                    txt_box_txt = "You may choose either Turtwig, Chimchar, Piplup."


                    turtwig_img = pygame.transform.scale(self.front_sprites['Turtwig'], (300, 300))
                    chimchar_img = pygame.transform.scale(self.front_sprites['Chimchar'], (300, 300))
                    piplup_img = pygame.transform.scale(self.front_sprites['Piplup'], (300, 300))

                    self.screen.blit(turtwig_img, (150, 150))
                    self.screen.blit(chimchar_img, (475, 150))
                    self.screen.blit(piplup_img, (788, 160))

                    if starter1.draw():
                        print("You picked Turtwig")

                        #Adds Turtwig to player party
                        self.player.party.append(create_pokemon(species = 'Turtwig', level = 5))
                        self.pokemon_buttons_created = False
                        pygame.mixer.music.stop()
                        self.game_state = 'home'

                        

                    elif starter2.draw():
                        print("You picked Chimchar")

                        #Adds Chimchar to player party
                        self.player.party.append(create_pokemon(species = 'Chimchar', level = 5))
                        self.pokemon_buttons_created = False
                        pygame.mixer.music.stop()
                        self.game_state = 'home'

                    elif starter3.draw():
                        print("You picked Piplup")

                        #Adds Piplup to player party
                        self.player.party.append(create_pokemon(species = 'Piplup', level = 5))
                        self.pokemon_buttons_created = False
                        pygame.mixer.music.stop()
                        self.game_state = 'home'
                    
                #Game home menu
                case 'home':
                    
                    self.temp_state = ''
                    self.in_battle = False
                    self.opposing_active_pokemon = False
                    if not self.home_music:
                        pygame.mixer.music.load('data/music/twinleaftowntheme.mp3')
                        pygame.mixer.music.play(-1)
                        self.home_music = True
                    

                    #puts text onto textbox
                    txt_box_txt = "What would you like to do?"


                    if wild_encounter.draw():
                        if healthy_pokemon == 0:
                            txt_box_txt = "You have no healthy pokemon!"
                            draw_text_box(self.screen, txt_box_txt)
                            pygame.display.update()
                            pygame.time.wait(2000)
                        else:
                            pygame.mixer.music.load('data/music/wildBattleTheme.mp3')
                            pygame.mixer.music.play(-1)
                            self.home_music = False
                            self.game_state = 'wild encounter'
                            self.temp_state = 'wild battle'

                    if trainer_battle.draw():
                        if healthy_pokemon == 0:
                            txt_box_txt = "You have no healthy pokemon!"
                            draw_text_box(self.screen, txt_box_txt)
                            pygame.display.update()
                            pygame.time.wait(2000)
                        else:
                            pygame.mixer.music.load('data/music/trainerbattletheme.mp3')
                            pygame.mixer.music.play(-1)
                            self.opposing_trainer = random_trainer(self.player.badges)
                            self.opposing_remaining_pokemon = len(self.opposing_trainer.party)
                            self.in_battle = True
                            self.game_state = 'check party'
                            self.temp_state = 'trainer battle'

                    if take_on_gym.draw():
                        if healthy_pokemon == 0:
                            txt_box_txt = "You have no healthy pokemon!"
                            draw_text_box(self.screen, txt_box_txt)
                            pygame.display.update()
                            pygame.time.wait(2000)
                        else:
                            pass

                    if check_pokemon.draw():
                        self.game_state = 'check party'
                    
                    if pokemon_center.draw():
                        pygame.mixer.music.load('data/music/healingsoundeffect.mp3')
                        pygame.mixer.music.play(1)
                        for i, pokemon in enumerate(self.player.party):
                            pokemon.hp = pokemon.stats[0]
                        txt_box_txt = "Your pokemon are all better"
                        draw_text_box(self.screen, txt_box_txt)
                        shop_button.draw()
                        pygame.display.update()
                        pygame.time.wait(3100)
                        self.home_music = False

                    if shop_button.draw():
                        pass

               

                case 'check party':

                    #Changes the background the a dark blue
                    self.display.fill((66, 36, 200))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    #Puts text into text box
                    txt_box_txt = "What pokemon would you like to look at?"

                    if self.in_battle:
                        txt_box_txt = "Choose a pokemon to send out or return home"


                    if not self.pokemon_buttons_created:
                        self.create_pokemon_buttons()

                    #Using buttons and a menu system took me way out of my element. And it takes so much time to code
                    for i, button in enumerate(self.pokemon_buttons):
                        if button.draw():
                            self.pokemon_buttons_created = False
                            if i == 0:
                                if self.in_battle:
                                    if self.player.party[0].hp > 0:
                                        self.player_pokemon = self.player.party[0]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)   
                                else:
                                    self.game_state = 'check pokemon 1'
                            elif i == 1:
                                if self.in_battle:
                                    if self.player.party[1].hp > 0:
                                        self.player_pokemon = self.player.party[1]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                else:
                                    self.game_state = 'check pokemon 2'
                            elif i == 2:
                                if self.in_battle:
                                    if self.player.party[2].hp > 0:
                                        self.player_pokemon = self.player.party[2]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                else:
                                    self.game_state = 'check pokemon 3'
                            elif i == 3:
                                if self.in_battle:
                                    if self.player.party[3].hp > 0:
                                        self.player_pokemon = self.player.party[3]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                else:
                                    self.game_state = 'check pokemon 4'
                            elif i == 4:
                                if self.in_battle:
                                    if self.player.party[4].hp > 0:
                                        self.player_pokemon = self.player.party[4]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                else:
                                    self.game_state = 'check pokemon 5'
                            elif i == 5:
                                if self.in_battle:
                                    if self.player.party[5].hp > 0:
                                        self.player_pokemon = self.player.party[5]
                                        self.game_state = self.temp_state
                                    else:
                                        txt_box_txt = "That pokemon has no HP left!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                else:
                                    self.game_state = 'check pokemon 6'

                    if return_button.draw():
                        self.pokemon_created = False
                        if self.in_battle:
                            pygame.mixer.music.stop()
                        self.game_state = 'home'


                case 'check pokemon 1':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[0].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[0].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[0].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[0].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[0].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[0].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[0].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[0].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[0].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[0].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[0].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'

                case 'check pokemon 2':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[1].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[1].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[1].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[1].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[1].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[1].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[1].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[1].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[1].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[1].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[1].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'

                case 'check pokemon 3':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[2].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[2].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[2].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[2].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[2].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[2].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[2].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[2].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[2].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[2].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[2].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'
                
                case 'check pokemon 4':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[3].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[3].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[3].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[3].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[3].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[3].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[3].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[3].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[3].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[3].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[3].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'

                case 'check pokemon 5':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[4].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[4].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[4].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[4].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[4].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[4].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[4].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[4].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[4].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[4].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[4].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'

                case 'check pokemon 6':

                    #Changes the background the a grey
                    self.display.fill((90, 90, 106))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "It is your " + self.player.party[5].species

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(40, 80, 1170, 100))

                    lv_txt = "Level: " + str(self.player.party[5].level)
                    self.draw_text(lv_txt, self.font, self.black, 60, 100)
                    gen_txt = "Gender: " + self.player.party[5].gender
                    self.draw_text(gen_txt, self.font, self.black, 470, 100)
                    nature_txt = "Nature: " + self.player.party[5].nature
                    self.draw_text(nature_txt, self.font, self.black, 880, 100)

                    pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(140, 280, 300, 250))
                    
                    hp_txt = "HP: " + str(self.player.party[5].stats[0])
                    self.draw_text(hp_txt, self.font, self.black, 160, 300)
                    atk_txt = "Attack: " + str(self.player.party[5].stats[1])
                    self.draw_text(atk_txt, self.font, self.black, 160, 335)
                    def_txt = "Defense: " + str(self.player.party[5].stats[2])
                    self.draw_text(def_txt, self.font, self.black, 160, 370)
                    spatk_txt = "Sp. Attack: " + str(self.player.party[5].stats[3])
                    self.draw_text(spatk_txt, self.font, self.black, 160, 405)
                    spdef_txt = "Sp. Defense: " + str(self.player.party[5].stats[4])
                    self.draw_text(spdef_txt, self.font, self.black, 160, 440)
                    spe_txt = "Speed: " + str(self.player.party[5].stats[5])
                    self.draw_text(spe_txt, self.font, self.black, 160, 475)

                    pokemon_img = pygame.transform.scale(self.front_sprites[self.player.party[5].species], (400, 400))
                    self.screen.blit(pokemon_img, (590, 188))

                    if return_button.draw():
                        self.game_state = 'check party'


                case 'wild encounter':

                    #Changes the background the a grassy green
                    self.display.fill((208, 252, 196))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    
                    if not self.pokemon_created:
                        lvl = 1
                        if self.player.badges == 0:
                            lvl = random.randint(1, 9)

                        if self.player.badges == 1:
                            lvl = random.randint(10, 19)

                        if self.player.badges == 2:
                            lvl = random.randint(20, 29)
                        
                        if self.player.badges == 3:
                            lvl = random.randint(30, 39)

                        if self.player.badges == 4:
                            lvl = random.randint(30, 49)

                        if self.player.badges == 5:
                            lvl = random.randint(30, 59)

                        if self.player.badges >= 6:
                            lvl = random.randint(30, 89)

                        wild_pokemon = create_pokemon(pNum = random_wild_pokemon(self.player.badges), level = lvl)
                        self.pokemon_created = True

                    txt_box_txt = "You've encountered a level " + str(wild_pokemon.level) + " " + wild_pokemon.species + ". What would you like to do?"
                    pokemon_img = pygame.transform.scale(self.front_sprites[wild_pokemon.species], (500, 500))
                    self.screen.blit(pokemon_img, (400, 100))

                    if battle_wild.draw():
                        self.opposing_pokemon = wild_pokemon
                        self.in_battle = True
                        self.game_state = 'check party'

                    if catch_wild.draw():
                        pygame.mixer.music.stop()
                        self.pokemon_created = False
                        self.player.party.append(wild_pokemon)
                        self.pokemon_buttons_created = False

                        if len(self.player.party) > 6:
                            self.game_state = 'choose remove pokemon'               
                        
                        else:
                            self.game_state = 'home'

                    if run_away.draw():
                        pygame.mixer.music.stop()
                        self.pokemon_created = False
                        self.game_state = 'home'


                case 'wild battle':

                    #Changes the background the a grassy green
                    self.display.fill((208, 252, 196))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    #puts text onto textbox
                    txt_box_txt = "Select a move!"

                    pygame.draw.ellipse(self.screen, (235, 232, 231), (50, 490, 440, 140))
                    pygame.draw.ellipse(self.screen, (235, 232, 231), (750, 290, 440, 140))

                    draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)

                    draw_player_pokemon_box(self.screen, self.player_pokemon)
                    
                    player_img = pygame.transform.scale(self.front_sprites[self.player_pokemon.species], (400, 400))
                    self.screen.blit(player_img, (70, 240))

                    opponent_img = pygame.transform.scale(self.front_sprites[self.opposing_pokemon.species], (360, 360))
                    self.screen.blit(opponent_img, (800, 30))


                    if not self.battle_buttons_created:
                        self.create_battle_buttons()

                    #Using buttons and a menu system took me way out of my element. And it takes so much time to code
                    for i, button in enumerate(self.battle_buttons):
                        if button.draw():
                            if i == 0:
                                player_move = create_move(self.battle_buttons[0].text, self.player_pokemon.type1, 60, True)
                                self.battle_phase = 1
                            elif i == 1:
                                player_move = create_move(self.battle_buttons[1].text, self.player_pokemon.type1, 60, False)
                                self.battle_phase = 1
                            elif i == 2:
                                player_move = create_move(self.battle_buttons[2].text, self.player_pokemon.type2, 60, True)
                                self.battle_phase = 1
                            elif i == 3:
                                player_move = create_move(self.battle_buttons[3].text, self.player_pokemon.type2, 60, False)
                                self.battle_phase = 1

                    match self.battle_phase:
                        case 0:
                            pass
                        case 1:
                            self.battle_text = True
                            self.battle_phase = 0
                            if self.opposing_pokemon.type2 == 'NONE':
                                opponent_int = random.randint(1, 2)
                            else:
                                opponent_int = random.randint(1, 4)
                            match opponent_int:
                                case 1:
                                    opposing_move_name = self.opposing_pokemon.type1 + " PHYS"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type1, 60, True)
                                case 2:
                                    opposing_move_name = self.opposing_pokemon.type1 + " SP"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type1, 60, False)
                                case 3:
                                    opposing_move_name = self.opposing_pokemon.type2 + " PHYS"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type2, 60, True)
                                case 4:
                                    opposing_move_name = self.opposing_pokemon.type2 + " SP"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type2, 60, False)
                            
                            # Determines move order based on pokemon speed stats
                            if self.player_pokemon.stats[5] < self.opposing_pokemon.stats[5]:
                                order = 0
                            elif self.player_pokemon.stats[5] > self.opposing_pokemon.stats[5]:
                                order = 1
                            else:
                                order = random.randint(0, 1)
                            

                            
                            match order:
                                
                                #Opposing pokemon moves first
                                case 0:
                                    
                                    new_hp = self.player_pokemon.hp - damage_calculator(opponent_move, self.opposing_pokemon, self.player_pokemon)
                                    if new_hp < 0:
                                        new_hp = 0
                                    
                                    #Display move
                                    txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                    draw_text_box(self.screen, txt_box_txt)
                                    pygame.display.update()
                                    pygame.time.wait(900)

                                    #Lower player pokemon hp
                                    while self.player_pokemon.hp >= new_hp:
                                        self.player_pokemon.hp -= 1
                                        draw_player_pokemon_box(self.screen, self.player_pokemon)
                                        txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.time.wait(60)
                                        pygame.display.update()
                                        if self.player_pokemon.hp == new_hp:
                                            if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) > 1:
                                                txt_box_txt = "It's super effective!"
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if 0 < calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) < 1:
                                                txt_box_txt = "It's not very effective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) == 0:
                                                txt_box_txt = "It's comepletely ineffective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)

                                            self.battle_text = False
                                            break

                                    #If player pokemon hasn't fainted, players turn to move
                                    if self.player_pokemon.hp > 0:
                                        new_hp = self.opposing_pokemon.hp - damage_calculator(player_move, self.player_pokemon, self.opposing_pokemon)
                                        if new_hp < 0:
                                            new_hp = 0
                                        
                                        #Display move
                                        txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(900)

                                        #Lower opposing pokemon hp
                                        while self.opposing_pokemon.hp >= new_hp:
                                            self.opposing_pokemon.hp -= 1
                                            draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)
                                            txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.time.wait(60)
                                            pygame.display.update()
                                            if self.opposing_pokemon.hp == new_hp:
                                                if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) > 1:
                                                    txt_box_txt = "It's super effective!"
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if 0 < calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) < 1:
                                                    txt_box_txt = "It's not very effective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) == 0:
                                                    txt_box_txt = "It's comepletely ineffective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                

                                                self.battle_text = False
                                                break
                                                
                                        #Opposing pokemon faints   
                                        if self.opposing_pokemon.hp <= 0:
                                            self.battle_buttons_created = False
                                            self.pokemon_created = False
                                            xp_gain, lvl_up = xpGain(self.player_pokemon, self.opposing_pokemon)
                                            txt_box_txt = "The wild " + self.opposing_pokemon.species + " fainted"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            txt_box_txt = self.player_pokemon.species + " gained " + str(xp_gain) + " exp!"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(1500)
                                            if lvl_up:
                                                txt_box_txt = self.player_pokemon.species + " grew to level " + str(self.player_pokemon.level)
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(2000)
                                                if self.player_pokemon.level >= pList[self.player_pokemon.pNum][4][0]:
                                                    self.is_evolving = True
                                                    draw_evolution(self.screen, self.player_pokemon)
                                                    self.is_evolving = False
                                            

                                            self.game_state = 'home'

                                    #Player pokemon faints
                                    else:
                                        healthy_pokemon -= 1
                                        txt_box_txt =  self.player_pokemon.species + " fainted"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                        if healthy_pokemon == 0:
                                            self.battle_buttons_created = False
                                            self.pokemon_created = False
                                            self.game_state = 'battle over'
                                        else:
                                            self.battle_buttons_created = False
                                            self.game_state = 'check party'
                                

                                #Player pokemon moves first
                                case 1:
                                    new_hp = self.opposing_pokemon.hp - damage_calculator(player_move, self.player_pokemon, self.opposing_pokemon)
                                    if new_hp < 0:
                                        new_hp = 0
                                    
                                    #Display move
                                    txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                    draw_text_box(self.screen, txt_box_txt)
                                    pygame.display.update()
                                    pygame.time.wait(900)

                                    #Lower opposing pokemon hp
                                    while self.opposing_pokemon.hp >= new_hp:
                                        self.opposing_pokemon.hp -= 1
                                        draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)
                                        txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.time.wait(60)
                                        pygame.display.update()
                                        if self.opposing_pokemon.hp == new_hp:
                                            if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) > 1:
                                                txt_box_txt = "It's super effective!"
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if 0 < calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) < 1:
                                                txt_box_txt = "It's not very effective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) == 0:
                                                txt_box_txt = "It's comepletely ineffective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)

                                            self.battle_text = False
                                            break

                                    # If opponent still has hp, it gets to move   
                                    if self.opposing_pokemon.hp > 0:
                                        new_hp = self.player_pokemon.hp - damage_calculator(opponent_move, self.opposing_pokemon, self.player_pokemon)
                                        if new_hp < 0:
                                            new_hp = 0
                                        
                                        #Display move
                                        txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(900)

                                        #Lower player pokemon hp
                                        while self.player_pokemon.hp >= new_hp:
                                            self.player_pokemon.hp -= 1
                                            draw_player_pokemon_box(self.screen, self.player_pokemon)
                                            txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.time.wait(60)
                                            pygame.display.update()
                                            if self.player_pokemon.hp == new_hp:
                                                if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) > 1:
                                                    txt_box_txt = "It's super effective!"
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if 0 < calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) < 1:
                                                    txt_box_txt = "It's not very effective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) == 0:
                                                    txt_box_txt = "It's comepletely ineffective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)

                                                self.battle_text = False
                                                break

                                        #Player pokemon faints   
                                        if self.player_pokemon.hp <= 0:
                                            healthy_pokemon -= 1
                                            txt_box_txt =  self.player_pokemon.species + " fainted"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            if healthy_pokemon == 0:
                                                self.battle_buttons_created = False
                                                self.pokemon_created = False
                                                self.game_state = 'battle over'
                                            else:
                                                self.battle_buttons_created = False
                                                self.game_state = 'check party'

                                    # Opponent pokemon faints
                                    else:
                                        self.battle_buttons_created = False
                                        self.pokemon_created = False
                                        xp_gain, lvl_up = xpGain(self.player_pokemon, self.opposing_pokemon)
                                        txt_box_txt = "The wild " + self.opposing_pokemon.species + " fainted"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                        txt_box_txt = self.player_pokemon.species + " gained " + str(xp_gain) + " exp!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(1500)
                                        if lvl_up:
                                            txt_box_txt = self.player_pokemon.species + " grew to level " + str(self.player_pokemon.level)
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            if self.player_pokemon.level >= pList[self.player_pokemon.pNum][4][0]:
                                                self.is_evolving = True
                                                draw_evolution(self.screen, self.player_pokemon)
                                                self.is_evolving = False

                                        self.game_state = 'home'

                        


                    if return_home.draw():
                            pygame.mixer.music.stop()
                            self.battle_buttons_created = False
                            self.pokemon_created = False
                            self.game_state = 'home'


                case 'trainer battle':
                    #Changes the background the a grassy green
                    self.display.fill((208, 252, 196))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))

                    #puts text onto textbox
                    txt_box_txt = "Select a move!"

                    pygame.draw.ellipse(self.screen, (235, 232, 231), (50, 490, 440, 140))
                    pygame.draw.ellipse(self.screen, (235, 232, 231), (750, 290, 440, 140))

                    if not self.opposing_active_pokemon:
                        for i, pokemon in enumerate(self.opposing_trainer.party):
                            if pokemon.hp > 0:
                                self.opposing_pokemon = pokemon

                                player_img = pygame.transform.scale(self.front_sprites[self.player_pokemon.species], (400, 400))
                                self.screen.blit(player_img, (70, 240))

                                opponent_img = pygame.transform.scale(self.front_sprites[self.opposing_pokemon.species], (360, 360))
                                self.screen.blit(opponent_img, (800, 30))
                                
                                txt_box_txt = "Your opponent sent out " + self.opposing_pokemon.species
                                draw_text_box(self.screen, txt_box_txt)
                                pygame.display.update()
                                pygame.time.wait(1000)
                                self.opposing_active_pokemon = True
                                break

                    draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)

                    draw_player_pokemon_box(self.screen, self.player_pokemon)
                    
                    player_img = pygame.transform.scale(self.front_sprites[self.player_pokemon.species], (400, 400))
                    self.screen.blit(player_img, (70, 240))

                    opponent_img = pygame.transform.scale(self.front_sprites[self.opposing_pokemon.species], (360, 360))
                    self.screen.blit(opponent_img, (800, 30))


                    if not self.battle_buttons_created:
                        self.create_battle_buttons()

                    #Using buttons and a menu system took me way out of my element. And it takes so much time to code
                    for i, button in enumerate(self.battle_buttons):
                        if button.draw():
                            if i == 0:
                                player_move = create_move(self.battle_buttons[0].text, self.player_pokemon.type1, 60, True)
                                self.battle_phase = 1
                            elif i == 1:
                                player_move = create_move(self.battle_buttons[1].text, self.player_pokemon.type1, 60, False)
                                self.battle_phase = 1
                            elif i == 2:
                                player_move = create_move(self.battle_buttons[2].text, self.player_pokemon.type2, 60, True)
                                self.battle_phase = 1
                            elif i == 3:
                                player_move = create_move(self.battle_buttons[3].text, self.player_pokemon.type2, 60, False)
                                self.battle_phase = 1

                    match self.battle_phase:
                        case 0:
                            pass
                        case 1:
                            self.battle_text = True
                            self.battle_phase = 0
                            if self.opposing_pokemon.type2 == 'NONE':
                                opponent_int = random.randint(1, 2)
                            else:
                                opponent_int = random.randint(1, 4)
                            match opponent_int:
                                case 1:
                                    opposing_move_name = self.opposing_pokemon.type1 + " PHYS"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type1, 60, True)
                                case 2:
                                    opposing_move_name = self.opposing_pokemon.type1 + " SP"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type1, 60, False)
                                case 3:
                                    opposing_move_name = self.opposing_pokemon.type2 + " PHYS"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type2, 60, True)
                                case 4:
                                    opposing_move_name = self.opposing_pokemon.type2 + " SP"
                                    opponent_move = create_move(opposing_move_name, self.opposing_pokemon.type2, 60, False)
                            
                            # Determines move order based on pokemon speed stats
                            if self.player_pokemon.stats[5] < self.opposing_pokemon.stats[5]:
                                order = 0
                            elif self.player_pokemon.stats[5] > self.opposing_pokemon.stats[5]:
                                order = 1
                            else:
                                order = random.randint(0, 1)
                            

                            
                            match order:
                                
                                #Opposing pokemon moves first
                                case 0:
                                    
                                    new_hp = self.player_pokemon.hp - damage_calculator(opponent_move, self.opposing_pokemon, self.player_pokemon)
                                    if new_hp < 0:
                                        new_hp = 0
                                    
                                    #Display move
                                    txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                    draw_text_box(self.screen, txt_box_txt)
                                    pygame.display.update()
                                    pygame.time.wait(900)

                                    #Lower player pokemon hp
                                    while self.player_pokemon.hp >= new_hp:
                                        self.player_pokemon.hp -= 1
                                        draw_player_pokemon_box(self.screen, self.player_pokemon)
                                        txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.time.wait(60)
                                        pygame.display.update()
                                        if self.player_pokemon.hp == new_hp:
                                            if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) > 1:
                                                txt_box_txt = "It's super effective!"
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if 0 < calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) < 1:
                                                txt_box_txt = "It's not very effective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) == 0:
                                                txt_box_txt = "It's comepletely ineffective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)

                                            self.battle_text = False
                                            break

                                    #If player pokemon hasn't fainted, players turn to move
                                    if self.player_pokemon.hp > 0:
                                        new_hp = self.opposing_pokemon.hp - damage_calculator(player_move, self.player_pokemon, self.opposing_pokemon)
                                        if new_hp < 0:
                                            new_hp = 0
                                        
                                        #Display move
                                        txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(900)

                                        #Lower opposing pokemon hp
                                        while self.opposing_pokemon.hp >= new_hp:
                                            self.opposing_pokemon.hp -= 1
                                            draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)
                                            txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.time.wait(60)
                                            pygame.display.update()
                                            if self.opposing_pokemon.hp == new_hp:
                                                if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) > 1:
                                                    txt_box_txt = "It's super effective!"
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if 0 < calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) < 1:
                                                    txt_box_txt = "It's not very effective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) == 0:
                                                    txt_box_txt = "It's comepletely ineffective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                

                                                self.battle_text = False
                                                break
                                                
                                        #Opposing pokemon faints   
                                        if self.opposing_pokemon.hp <= 0:
                                            self.battle_buttons_created = False
                                            self.pokemon_created = False
                                            xp_gain, lvl_up = xpGain(self.player_pokemon, self.opposing_pokemon)
                                            txt_box_txt = "The opponent's " + self.opposing_pokemon.species + " fainted"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            txt_box_txt = self.player_pokemon.species + " gained " + str(xp_gain) + " exp!"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(1500)
                                            if lvl_up:
                                                txt_box_txt = self.player_pokemon.species + " grew to level " + str(self.player_pokemon.level)
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(2000)
                                                if self.player_pokemon.level >= pList[self.player_pokemon.pNum][4][0]:
                                                    self.is_evolving = True
                                                    draw_evolution(self.screen, self.player_pokemon)
                                                    self.is_evolving = False
                                            self.opposing_remaining_pokemon -= 1
                                            self.opposing_active_pokemon = False
                                            
                                            if self.opposing_remaining_pokemon <= 0:
                                                self.game_state = 'battle over'

                                    #Player pokemon faints
                                    else:
                                        healthy_pokemon -= 1
                                        txt_box_txt =  self.player_pokemon.species + " fainted"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                        if healthy_pokemon == 0:
                                            self.battle_buttons_created = False
                                            self.pokemon_created = False
                                            self.game_state = 'battle over'
                                        else:
                                            self.battle_buttons_created = False
                                            self.game_state = 'check party'
                                

                                #Player pokemon moves first
                                case 1:
                                    new_hp = self.opposing_pokemon.hp - damage_calculator(player_move, self.player_pokemon, self.opposing_pokemon)
                                    if new_hp < 0:
                                        new_hp = 0
                                    
                                    #Display move
                                    txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                    draw_text_box(self.screen, txt_box_txt)
                                    pygame.display.update()
                                    pygame.time.wait(900)

                                    #Lower opposing pokemon hp
                                    while self.opposing_pokemon.hp >= new_hp:
                                        self.opposing_pokemon.hp -= 1
                                        draw_opposing_pokemon_box(self.screen, self.opposing_pokemon)
                                        txt_box_txt = self.player_pokemon.species + " used " + player_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.time.wait(60)
                                        pygame.display.update()
                                        if self.opposing_pokemon.hp == new_hp:
                                            if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) > 1:
                                                txt_box_txt = "It's super effective!"
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if 0 < calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) < 1:
                                                txt_box_txt = "It's not very effective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)
                                            if calculate_effectiveness(player_move.type, self.opposing_pokemon.type1, self.opposing_pokemon.type2) == 0:
                                                txt_box_txt = "It's comepletely ineffective."
                                                draw_text_box(self.screen, txt_box_txt)
                                                pygame.display.update()
                                                pygame.time.wait(1900)

                                            self.battle_text = False
                                            break

                                    # If opponent still has hp, it gets to move   
                                    if self.opposing_pokemon.hp > 0:
                                        new_hp = self.player_pokemon.hp - damage_calculator(opponent_move, self.opposing_pokemon, self.player_pokemon)
                                        if new_hp < 0:
                                            new_hp = 0
                                        
                                        #Display move
                                        txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(900)

                                        #Lower player pokemon hp
                                        while self.player_pokemon.hp >= new_hp:
                                            self.player_pokemon.hp -= 1
                                            draw_player_pokemon_box(self.screen, self.player_pokemon)
                                            txt_box_txt = "Opposing " + self.opposing_pokemon.species + " used " + opponent_move.name
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.time.wait(60)
                                            pygame.display.update()
                                            if self.player_pokemon.hp == new_hp:
                                                if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) > 1:
                                                    txt_box_txt = "It's super effective!"
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if 0 < calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) < 1:
                                                    txt_box_txt = "It's not very effective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)
                                                if calculate_effectiveness(opponent_move.type, self.player_pokemon.type1, self.player_pokemon.type2) == 0:
                                                    txt_box_txt = "It's comepletely ineffective."
                                                    draw_text_box(self.screen, txt_box_txt)
                                                    pygame.display.update()
                                                    pygame.time.wait(1900)

                                                self.battle_text = False
                                                break

                                        #Player pokemon faints   
                                        if self.player_pokemon.hp <= 0:
                                            healthy_pokemon -= 1
                                            txt_box_txt =  self.player_pokemon.species + " fainted"
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            if healthy_pokemon == 0:
                                                self.battle_buttons_created = False
                                                self.pokemon_created = False
                                                self.game_state = 'battle over'
                                            else:
                                                self.battle_buttons_created = False
                                                self.game_state = 'check party'

                                    # Opponent pokemon faints
                                    else:
                                        self.battle_buttons_created = False
                                        self.pokemon_created = False
                                        xp_gain, lvl_up = xpGain(self.player_pokemon, self.opposing_pokemon)
                                        txt_box_txt = "The opponent's " + self.opposing_pokemon.species + " fainted"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(2000)
                                        txt_box_txt = self.player_pokemon.species + " gained " + str(xp_gain) + " exp!"
                                        draw_text_box(self.screen, txt_box_txt)
                                        pygame.display.update()
                                        pygame.time.wait(1500)
                                        if lvl_up:
                                            txt_box_txt = self.player_pokemon.species + " grew to level " + str(self.player_pokemon.level)
                                            draw_text_box(self.screen, txt_box_txt)
                                            pygame.display.update()
                                            pygame.time.wait(2000)
                                            if self.player_pokemon.level >= pList[self.player_pokemon.pNum][4][0]:
                                                self.is_evolving = True
                                                draw_evolution(self.screen, self.player_pokemon)
                                                self.is_evolving = False

                                        self.opposing_remaining_pokemon -= 1
                                        self.opposing_active_pokemon = False
                                        
                                        if self.opposing_remaining_pokemon <= 0:
                                            self.game_state = 'battle over'

                        


                    if return_home.draw():
                            pygame.mixer.music.stop()
                            self.battle_buttons_created = False
                            self.pokemon_created = False
                            self.game_state = 'home'


                case 'battle over':
                    txt_box_txt = "Battle over"

                    if return_home.draw():
                            pygame.mixer.music.stop()
                            self.battle_buttons_created = False
                            self.game_state = 'home'


                case 'choose remove pokemon':

                    #Changes the background the a dark blue
                    self.display.fill((66, 36, 200))

                    #blits display onto the screen
                    self.screen.blit(self.display, (0, 0))


                    txt_box_txt = "You have too many pokemon! Select one to remove from your party."


                    if not self.pokemon_buttons_created:
                        self.create_pokemon_buttons()

                    #Using buttons and a menu system took me way out of my element. And it takes so much time to code
                    for i, button in enumerate(self.pokemon_buttons):
                        if button.draw():
                            self.pokemon_buttons_created = False
                            if i == 0:
                                removed_pokemon = self.player.party[0]
                                self.player.party.remove(removed_pokemon)
                            elif i == 1:
                                removed_pokemon = self.player.party[1]
                                self.player.party.remove(removed_pokemon)
                            elif i == 2:
                                removed_pokemon = self.player.party[2]
                                self.player.party.remove(removed_pokemon)
                            elif i == 3:
                                removed_pokemon = self.player.party[3]
                                self.player.party.remove(removed_pokemon)
                            elif i == 4:
                                removed_pokemon = self.player.party[4]
                                self.player.party.remove(removed_pokemon)
                            elif i == 5:
                                removed_pokemon = self.player.party[5]
                                self.player.party.remove(removed_pokemon)
                            elif i == 6:
                                removed_pokemon = self.player.party[6]
                                self.player.party.remove(removed_pokemon)
                            self.game_state = 'home'


                case _:
                    self.draw_text("Something is wrong, please exit the window", self.font, self.black, 60, 700)

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            if not self.battle_text and not self.is_evolving:
                draw_text_box(self.screen, txt_box_txt)

     
            pygame.display.update()
            self.clock.tick(60)

            
Game().run()      



