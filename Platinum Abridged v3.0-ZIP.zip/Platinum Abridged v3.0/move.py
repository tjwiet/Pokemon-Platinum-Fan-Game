
class Damage_Move:
    def __init__(self, name, type, power, isPhys):
        self.name = name
        self.type = type
        self.power = power
        self.isPhys = isPhys

def create_move(name = '', type = 'NORMAL', power = 1, isPhys = True):
    return Damage_Move(name, type, power, isPhys)


