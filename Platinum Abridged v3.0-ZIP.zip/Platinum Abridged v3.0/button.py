import pygame

class Button():
    black = (0, 0, 0)

    def __init__(self, surface, x, y, text):
        self.rect = pygame.Rect(x, y, 210, 60)
        self.surface = surface
        self.x = x
        self.y = y
        self.text = text
        self.button_font = pygame.font.Font('freesansbold.ttf', 20)
        self.clicked = False

    
    def draw_button_text(self, text, font, color, x, y):
        img = font.render(text, True, color)
        self.surface.blit(img, (x, y))

    def draw(self):
        action = False

        #get mmouse position
        pos = pygame.mouse.get_pos()

        #Check for mouse click on button
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True

            if pygame.mouse.get_pressed()[0] == 0 and self.clicked == True:
                self.clicked = False
                action = True
        
        #Draw the button on the screen
        pygame.draw.rect(self.surface, self.black, pygame.Rect(self.x, self.y, 210, 60))
        pygame.draw.rect(self.surface, (255, 255, 255), pygame.Rect((self.x + 1), (self.y + 1), 208, 58))
        self.draw_button_text(self.text, self.button_font, self.black, (self.x + 5), (self.y + 20))

        return action