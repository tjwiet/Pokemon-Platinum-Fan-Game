from PokemonCollectionv3 import speciesList
import random



def ivCalculator():
    iv = [0,0,0,0,0,0]
    i = 0
    while i < len(iv):
        iv[i] = random.randint(0, 31)
        i += 1
    return iv



def statCalc(pNum, nature, iv, level, ev):
    stats = []
    stats.append((((2*speciesList[pNum][2][0]) + iv[0] + ((int(ev[0])/4)))*(level/100)) + level + 10) # HP
    stats.append((((2*speciesList[pNum][2][1]) + iv[1] + (int(ev[1])/4))*(level/100) + 5))            # Attack
    stats.append((((2*speciesList[pNum][2][2]) + iv[2] + (int(ev[2])/4))*(level/100) + 5))            # Defense
    stats.append((((2*speciesList[pNum][2][3]) + iv[3] + (int(ev[3])/4))*(level/100) + 5))            # Special Attack
    stats.append((((2*speciesList[pNum][2][4]) + iv[4] + (int(ev[4])/4))*(level/100) + 5))            # Special Defense
    stats.append((((2*speciesList[pNum][2][5]) + iv[5] + (int(ev[5])/4))*(level/100) + 5))            # Speed


    # Attack Up
    atkup = ['Adamant', 'Brave', 'Lonely', 'Naughty']
    if nature in atkup:
        stats[1] = stats[1]*1.1
    # Attack Down
    atkdown = ['Bold', 'Calm', 'Modest', 'Timid']
    if nature in atkdown:
        stats[1] = stats[1]*0.9
    
    # Defense Up
    defup = ['Bold', 'Impish', 'Lax', 'Relaxed']
    if nature in defup:
        stats[2] = stats[2]*1.1
    # Defense Down
    defdown = ['Gentle', 'Hasty', 'Lonely', 'Mild']
    if nature in defdown:
        stats[2] = stats[2]*0.9

    # Special Attack Up
    spaup = ['Mild', 'Modest', 'Quiet', 'Rash']
    if nature in spaup:
        stats[3] = stats[3]*1.1
    # Special Attack Down
    spadown = ['Adamant', 'Careful', 'Impish', 'Jolly']
    if nature in spadown:
        stats[3] = stats[3]*0.9
    
    # Special Defense Up
    spdup = ['Calm', 'Careful', 'Gentle', 'Sassy']
    if nature in spdup:
        stats[4] = stats[4]*1.1
    # Special Defense Down
    spddown = ['Lax', 'Naive', 'Naughty', 'Rash']
    if nature in spddown:
        stats[4] = stats[4]*0.9
    
    # Speed Up
    speup = ['Hasty', 'Jolly', 'Naive', 'Timid']
    if nature in speup:
        stats[5] = stats[5]*1.1
    # Speed Down
    spedown = ['Brave', 'Quiet', 'Relaxed', 'Sassy']
    if nature in spedown:
        stats[5] = stats[5]*0.9
    
    finishedStats = [int(i) for i in stats]

    return finishedStats



def xpCalc(level):
    xp = level**3
    return xp

def xpGain(player_pokemon, defeated_pokemon):
    lvl_up = False
    current_level = player_pokemon.level
    xp_gain_part1 = (100 * defeated_pokemon.level) / (5)
    xp_gain_part2 = (((2 * defeated_pokemon.level) + 10) / (defeated_pokemon.level + player_pokemon.level + 10)) ** (5 / 2) 
    xp_gain = int((xp_gain_part1 * xp_gain_part2) + 1)
    player_pokemon.xp += xp_gain
    
    player_pokemon.level = int(player_pokemon.xp ** (1/3))
    if player_pokemon.level > 100:
        player_pokemon.level = 100
    if player_pokemon.level > current_level:
        lvl_up = True
        player_pokemon.stats = statCalc(player_pokemon.pNum, player_pokemon.nature, player_pokemon.ivSpread, player_pokemon.level, [0, 0, 0, 0, 0, 0])
    return xp_gain, lvl_up

    



def damage_calculator(move, attacker, defender):
    # Most of these are not used in this game. But I included them anyway so that should
    # I choose to develope this further, I don't have to change too much about the algorithm

    burn = 1
    screen = 1
    targets = 1
    weather = 1
    flash_fire = 1
    solid_rock_filter = 1
    expert_belt = 1
    tinted_lens = 1
    berry = 1
    if random.randint(1, 10000) <= 625:
        critical = 2
    else:
        critical = 1
    item = 1
    me_first = 1
    roll = random.randint(85, 100) / 100
    if move.type == attacker.type1 or move.type == attacker.type2:
        stab = 1.5
    else:
        stab = 1
    if move.isPhys:
        offense = attacker.stats[1]
        defense = defender.stats[2]
    else:
        offense = attacker.stats[3]
        defense = defender.stats[4]
    level = attacker.level
    effectiveness = calculate_effectiveness(move.type, defender.type1, defender.type2)
    
    
    damage_part1 = ((((2 * level) / 5) + 2) * move.power * (offense/defense)) / 50
    damage_part2 = (burn * screen * targets * weather * flash_fire) + 2
    damage_part3 = critical * item * me_first * roll * stab * effectiveness * solid_rock_filter * expert_belt * tinted_lens * berry
    damage = damage_part1 * damage_part2 * damage_part3
    return int(damage)


def calculate_effectiveness(offensive_type, defensive_type1, defensive_type2):

    move_effectiveness = {
        'NORMAL' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 0, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 0.5, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'GRASS' : {'NORMAL' : 1, 'GRASS' : 0.5, 'FIRE' : 0.5, 'WATER' : 2, 'ELECTRIC' : 1, 'FLYING' : 0.5, 'BUG' : 0.5, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 0.5, 'GROUND' : 2, 'ROCK' : 2, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 0.5, 'FAIRY' : 1, 'NONE': 1},
        'FIRE' : {'NORMAL' : 1, 'GRASS' : 2, 'FIRE' : 0.5, 'WATER' : 0.5, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 2, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 0.5, 'STEEL' : 2, 'ICE' : 2, 'DRAGON' : 0.5, 'FAIRY' : 1, 'NONE': 1},
        'WATER' : {'NORMAL' : 1, 'GRASS' : 0.5, 'FIRE' : 2, 'WATER' : 0.5, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 2, 'ROCK' : 2, 'STEEL' : 1, 'ICE' : 1, 'DRAGON' : 0.5, 'FAIRY' : 1, 'NONE': 1},
        'ELECTRIC' : {'NORMAL' : 1, 'GRASS' : 0.5, 'FIRE' : 1, 'WATER' : 2, 'ELECTRIC' : 0.5, 'FLYING' : 2, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 0, 'ROCK' : 1, 'STEEL' : 1, 'ICE' : 1, 'DRAGON' : 0.5, 'FAIRY' : 1, 'NONE': 1},
        'FLYING' : {'NORMAL' : 1, 'GRASS' : 2, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 0.5, 'FLYING' : 1, 'BUG' : 2, 'FIGHTING' : 2, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 0.5, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'BUG' : {'NORMAL' : 1, 'GRASS' : 2, 'FIRE' : 0.5, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 0.5, 'BUG' : 1, 'FIGHTING' : 0.5, 'PSYCHIC' : 2, 'DARK' : 2, 'GHOST' : 0.5, 'POISON' : 0.5, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 0.5, 'NONE': 1},
        'FIGHTING' : {'NORMAL' : 2, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 0.5, 'BUG' : 0.5, 'FIGHTING' : 1, 'PSYCHIC' : 0.5, 'DARK' : 2, 'GHOST' : 0, 'POISON' : 0.5, 'GROUND' : 1, 'ROCK' : 2, 'STEEL' : 2, 'ICE' : 2, 'DRAGON' : 1, 'FAIRY' : 0.5, 'NONE': 1},
        'PSYCHIC' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 2, 'PSYCHIC' : 0.5, 'DARK' : 0, 'GHOST' : 1, 'POISON' : 2, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'DARK' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 0.5, 'PSYCHIC' : 2, 'DARK' : 0.5, 'GHOST' : 2, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 1, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 0.5, 'NONE': 1},
        'GHOST' : {'NORMAL' : 0, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 2, 'DARK' : 0.5, 'GHOST' : 2, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 1, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'POISON' : {'NORMAL' : 1, 'GRASS' : 2, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 0.5, 'POISON' : 0.5, 'GROUND' : 0.5, 'ROCK' : 0.5, 'STEEL' : 0, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 2, 'NONE': 1},
        'GROUND' : {'NORMAL' : 1, 'GRASS' : 0.5, 'FIRE' : 2, 'WATER' : 1, 'ELECTRIC' : 2, 'FLYING' : 0, 'BUG' : 0.5, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 2, 'STEEL' : 2, 'ICE' : 1, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'ROCK' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 2, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 2, 'BUG' : 2, 'FIGHTING' : 0.5, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 0.5, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 2, 'DRAGON' : 1, 'FAIRY' : 1, 'NONE': 1},
        'STEEL' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 0.5, 'WATER' : 0.5, 'ELECTRIC' : 0.5, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 2, 'STEEL' : 0.5, 'ICE' : 2, 'DRAGON' : 1, 'FAIRY' : 2, 'NONE': 1},
        'ICE' : {'NORMAL' : 1, 'GRASS' : 2, 'FIRE' : 0.5, 'WATER' : 0.5, 'ELECTRIC' : 1, 'FLYING' : 2, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 2, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 0.5, 'DRAGON' : 2, 'FAIRY' : 1, 'NONE': 1},
        'DRAGON' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 1, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 1, 'PSYCHIC' : 1, 'DARK' : 1, 'GHOST' : 1, 'POISON' : 1, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 2, 'FAIRY' : 0, 'NONE': 1},
        'FAIRY' : {'NORMAL' : 1, 'GRASS' : 1, 'FIRE' : 0.5, 'WATER' : 1, 'ELECTRIC' : 1, 'FLYING' : 1, 'BUG' : 1, 'FIGHTING' : 2, 'PSYCHIC' : 1, 'DARK' : 2, 'GHOST' : 1, 'POISON' : 0.5, 'GROUND' : 1, 'ROCK' : 1, 'STEEL' : 0.5, 'ICE' : 1, 'DRAGON' : 2, 'FAIRY' : 1, 'NONE': 1},
    }

    effectiveness = move_effectiveness[offensive_type][defensive_type1] * move_effectiveness[offensive_type][defensive_type2]
    return effectiveness
