import random
from trainer import Trainer
from pokemon import create_pokemon


def wildEncounterList(badges):
    commons = []
    uncommons = []
    rares = []
    elusives = []
    legendaries = []
    if badges >= 0:
        commons.extend([10, 13, 15, 20, 23])
        uncommons.extend([17, 32])
        rares.extend([26])
        elusives.extend([60])
        legendaries.extend([75])
    if badges >= 1:
        commons.extend([35, 38, 42, 47])
        uncommons.extend([11, 14, 16, 21, 45])
        rares.extend([18, 28, 30, 97])
        elusives.extend([40, 58])
    if badges >= 2:
        commons.extend([37, 68])
        uncommons.extend([24, 39, 43])
        rares.extend([33, 36, 51, 52, 89])
        elusives.extend([79])
        legendaries.extend([74])
    if badges >= 3:
        commons.extend([49, 62])
        uncommons.extend([48, 86])
        rares.extend([25, 27, 94])
        elusives.extend([80])
    if badges >= 4:
        commons.extend([65])
        uncommons.extend([69])
        rares.extend([63, 67, 87, 91])
        elusives.extend([55, 81])
        legendaries.extend([76])
    if badges >= 5:
        uncommons.extend([46])
        rares.extend([50, 83])
    if badges >= 6:
        commons.extend([70])
        uncommons.extend([66])
        rares.extend([53, 72])
        elusives.extend([54])
    if badges >= 7:
        legendaries.extend([77, 78, 100])
    if badges >= 8:
        elusives.extend([1, 4, 7])
        legendaries.extend([101])
    return commons, uncommons, rares, elusives, legendaries

def trainerEncounterList(badges):
    commons = []
    uncommons = []
    rares = []
    elusives = []
    if badges >= 0:
        commons.extend([10, 13, 15, 20, 23])
        uncommons.extend([17, 32])
        rares.extend([26])
        elusives.extend([1, 4, 7, 60])
    if badges >= 1:
        commons.extend([35, 38, 42, 47])
        uncommons.extend([11, 14, 16, 21, 45])
        rares.extend([18, 28, 30, 97])
        elusives.extend([1, 4, 7, 40, 58, 80])
    if badges >= 2:
        commons.extend([37, 68])
        uncommons.extend([24, 39, 43])
        rares.extend([33, 36, 51, 52, 89])
        elusives.extend([2, 5, 8, 79])
    if badges >= 3:
        commons.extend([49, 62])
        uncommons.extend([48, 86])
        rares.extend([25, 27, 29, 31, 94, 98])
        elusives.extend([81])
    if badges >= 4:
        commons.extend([65])
        uncommons.extend([69])
        rares.extend([12, 19, 63, 67, 87, 91, 92, 95])
        elusives.extend([41, 55])
    if badges >= 5:
        uncommons.extend([44, 46])
        rares.extend([22, 34, 50, 83, 88, 99])
    if badges >= 6:
        commons.extend([70, 71])
        uncommons.extend([66])
        rares.extend([53, 64, 72, 90, 93, 96])
        elusives.extend([3, 6, 9, 54])
    if badges >= 7:
        rares.extend([73, 82, 84, 85])
        elusives.extend([56, 59, 61])
    if badges >= 8:
        elusives.extend([57])
    return commons, uncommons, rares, elusives


def random_wild_pokemon(badges):
    commons, uncommons, rares, elusives, legendaries = wildEncounterList(badges)
    pNum = 0
    i = random.randint(1, 1000)
    if i <= 2:
        pNum = random.choice(legendaries)
    elif i <= 22:
        pNum = random.choice(elusives)
    elif i <= 122:
        pNum = random.choice(rares)
    elif i <= 362:
        pNum = random.choice(uncommons)
    else:
        pNum = random.choice(commons)
    return pNum

def random_trainer(badges):
    opposing_trainer = Trainer("Opposing Trainer", [], 0, 0)
    party_size = random.randint(2, 6)

    i = 1
    while i <= party_size:
        lvl = 1
        if badges == 0:
            lvl = random.randint(5, 10)
        if badges == 2:
            lvl = random.randint(15, 19)
        if badges == 2:
            lvl = random.randint(20, 29)
        if badges == 3:
            lvl = random.randint(30, 39)
        if badges == 4:
            lvl = random.randint(40, 49)
        if badges == 5:
            lvl = random.randint(50, 59)
        if badges >= 6:
            lvl = random.randint(60, 89)
        opposing_trainer.party.append(create_pokemon(pNum = random_trainer_pokemon(badges), level = lvl))
        i += 1

    return opposing_trainer
        
    

def random_trainer_pokemon(badges):
    commons, uncommons, rares, elusives = trainerEncounterList(badges)
    pNum = 0
    i = random.randint(1, 1000)
    if i <= 22:
        pNum = random.choice(elusives)
    elif i <= 122:
        pNum = random.choice(rares)
    elif i <= 362:
        pNum = random.choice(uncommons)
    else:
        pNum = random.choice(commons)
    return pNum