
class Trainer:
    def __init__(self, name, party, badges, money):
        self.name = name
        self.party = party
        self.badges = badges
        self.money = money