import pygame
from assets import front_sprite_list
from pokemon import create_pokemon
from PokemonCollectionv3 import speciesList

pList = speciesList

def draw_text_box(surface, text):

    txt_box_font = pygame.font.Font('freesansbold.ttf', 56)

    pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(39, 649, 1172, 202))
    pygame.draw.rect(surface, (255, 255, 255), pygame.Rect(40, 650, 1170, 200))
    pygame.draw.rect(surface, (0, 0, 0), pygame.Rect(45, 655, 1160, 190))
    pygame.draw.rect(surface, (255, 255, 255), pygame.Rect(50, 660, 1150, 180))

    txt_list = list(text)
    if len(txt_list) > 37:
        found = False
        i = 37
        while not found and i >= 0:
            if txt_list[i] == ' ':
                found = True
                i += 2
            i -= 1
        if not found:
             i = 37
        bot_txt = txt_list[i:]
        del txt_list[i:]
        top_txt = ''.join(txt_list)
        bot_txt = ''.join(bot_txt)
    else:
         top_txt = text
         bot_txt = ''

    draw_text(surface, top_txt, txt_box_font, (0, 0, 0), 60, 680)
    draw_text(surface, bot_txt, txt_box_font, (0, 0, 0), 60, 760)


def evolution_background(surface):
    surface.fill((16, 48, 42))
    surface.blit(surface, (0, 0))
    pygame.draw.ellipse(surface, (27, 80, 70), (-500, 10, 2250, 1800))
    pygame.draw.ellipse(surface, (37, 112, 98), (-501, 20, 2252, 1800))
    pygame.draw.ellipse(surface, (48, 144, 126), (-503, 34, 2256, 1800))
    pygame.draw.ellipse(surface, (59, 176, 154), (-510, 50, 2270, 1800))
    pygame.draw.ellipse(surface, (69, 208, 182), (-550, 70, 2350, 1800))
    pygame.draw.ellipse(surface, (80, 240, 210), (-600, 100, 2450, 1800))

    pygame.draw.ellipse(surface, (109, 243, 218), (-1000, 460, 3250, 1800))
    pygame.draw.ellipse(surface, (138, 246, 226), (-1000, 480, 3250, 1800))
    pygame.draw.ellipse(surface, (168, 249, 234), (-1000, 500, 3250, 1800))
    pygame.draw.ellipse(surface, (198, 252, 242), (-1000, 520, 3250, 1800))
    pygame.draw.ellipse(surface, (227, 255, 250), (-1000, 555, 3250, 1800))
    pygame.draw.ellipse(surface, (254, 255, 255), (-1000, 570, 3250, 1800))
     

def draw_evolution(surface, pokemon):
    pygame.mixer.music.stop()
    evolution_background(surface)
    x_size = 480
    y_size = 480
    x = 385
    y = 140
    start_time = pygame.time.get_ticks()
    while pygame.time.get_ticks() - start_time < 6000:
        evolution_background(surface)
        img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
        surface.blit(img, (x, y))
        txt_box_txt = "Huh? " + pokemon.species + " is evolving!"
        draw_text_box(surface, txt_box_txt)
        pygame.display.update()
    
    pygame.mixer.music.load('data/music/evolution.mp3')
    pygame.mixer.music.play(1)

    i = 1
    while i <= 235:
        x_size -= 2
        y_size -= 2
        x += 1
        y += 1
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 9:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    i = 1
    while i <= 47:
        x_size += 10
        y_size += 10
        x -= 5
        y -= 5
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 8:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    i = 1
    while i <= 47:
        x_size -= 10
        y_size -= 10
        x += 5
        y += 5
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 6:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    i = 1
    while i <= 47:
        x_size += 10
        y_size += 10
        x -= 5
        y -= 5
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 4:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    j = 1
    while j <= 15:
        i = 1
        while i <= 47:
            x_size -= 10
            y_size -= 10
            x += 5
            y += 5
            start_time = pygame.time.get_ticks()
            while pygame.time.get_ticks() - start_time < 4:
                evolution_background(surface)
                draw_text_box(surface, txt_box_txt)
                img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
                surface.blit(img, (x, y))
                pygame.display.update()
            i += 1
        i = 1
        while i <= 47:
            x_size += 10
            y_size += 10
            x -= 5
            y -= 5
            start_time = pygame.time.get_ticks()
            while pygame.time.get_ticks() - start_time < 4:
                evolution_background(surface)
                draw_text_box(surface, txt_box_txt)
                img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
                surface.blit(img, (x, y))
                pygame.display.update()
            i += 1
        j += 1
    i = 1
    while i <= 47:
        x_size -= 10
        y_size -= 10
        x += 5
        y += 5
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 2:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pokemon.species], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    j = 1
    while j <= 5:
        i = 1
        while i <= 47:
            x_size += 10
            y_size += 10
            x -= 5
            y -= 5
            start_time = pygame.time.get_ticks()
            while pygame.time.get_ticks() - start_time < 10:
                evolution_background(surface)
                draw_text_box(surface, txt_box_txt)
                pygame.draw.ellipse(surface, (255, 255, 255), (x, y, x_size, y_size))
                pygame.display.update()
            i += 1
        i = 1
        while i <= 47:
            x_size -= 10
            y_size -= 10
            x += 5
            y += 5
            start_time = pygame.time.get_ticks()
            while pygame.time.get_ticks() - start_time < 10:
                evolution_background(surface)
                draw_text_box(surface, txt_box_txt)
                pygame.draw.ellipse(surface, (255, 255, 255), (x, y, x_size, y_size))
                pygame.display.update()
            i += 1
        j += 1
    i = 1
    while i <= 47:
        x_size += 10
        y_size += 10
        x -= 5
        y -= 5
        start_time = pygame.time.get_ticks()
        while pygame.time.get_ticks() - start_time < 7:
            evolution_background(surface)
            draw_text_box(surface, txt_box_txt)
            img = pygame.transform.scale(front_sprite_list[pList[pokemon.pNum][4][1]], (x_size, y_size))
            surface.blit(img, (x, y))
            pygame.display.update()
        i += 1
    start_time = pygame.time.get_ticks()
    while pygame.time.get_ticks() - start_time < 1500:
        pass
    start_time = pygame.time.get_ticks()
    while pygame.time.get_ticks() - start_time < 4500:
        txt_box_txt = pokemon.species + " evolved into " + pList[pokemon.pNum][4][1]
        draw_text_box(surface, txt_box_txt)
        pygame.display.update()
    new_pokemon = create_pokemon(species = pList[pokemon.pNum][4][1], gender = pokemon.gender,  nature = pokemon.nature, ivSpread = pokemon.ivSpread, level = pokemon.level, xp = pokemon.xp, isShiny = pokemon.isShiny)
    return new_pokemon
    

    

         

    
    
    



def draw_text(surface, text, font, color, x, y):
        img = font.render(text, True, color)
        surface.blit(img, (x, y))
